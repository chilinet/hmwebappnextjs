export default function Footer() {
    return (
      <h2> </h2>
  );
}
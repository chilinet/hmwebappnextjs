/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: [
      'heatmanagerapptest-awe7auhwdbgcfvcc.germanywestcentral-01.azurewebsites.net',
      'webapp02.heatmanager.cloud',
      'localhost'
    ],
  },
  async rewrites() {
    return [
      {
        source: '/api/:path*',
        destination: '/api/:path*',
      },
    ];
  },
}

module.exports = nextConfig 